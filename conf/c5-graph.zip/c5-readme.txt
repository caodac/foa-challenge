
In this challenge, you're asked to derive a number of properties
based on a hypotheotical knowledge hypergraph. The graph is
undirected. The format is as follows: The two numbers in the
first line denote the number of nodes and edges in the graph,
respectively. The section immediately followed specifies the nodes.
Each node is defined by its unique identifier and associated labels.
Similarly, each edge is defined by its two end points and
associated labels. If we consider each edge label to correspond to
a link between two nodes, then the number of labels on an edge
is the number of links between two nodes.

Consider the following hypergraph:

10 18
364 V001 V002 V003
10142 V001 V002 V003
333355 V002 V003
558814 V002 V003
703053 V002 V004
1020765 V002 V004
1026814 V002 V004
1169138 V002 V005 V006 V007 V008 V009
1216273 V010 V002 V011 V005 V012 V007 V013 V009
1263901 V002 V014
10142 1026814 E001 E002 E003 E004 E005 E006 E007 E008 E009 E010 E011 E012 E013 E014 E015 E016 E017
558814 1026814 E001 E018 E019
1026814 1169138 E001 E011 E012 E013 E014 E015 E016 E017 E020
558814 1169138 E011 E021
10142 1169138 E011 E012 E013 E014 E015 E016 E017
364 333355 E013 E022
364 703053 E001 E011 E013 E015 E017 E022 E023 E024 E025 E026
333355 703053 E013 E022
333355 1020765 E001 E011 E013 E015 E017 E022 E027 E028 E029 E030 E031
364 1020765 E013 E022
703053 1020765 E013 E022
1020765 1216273 E001 E011 E013 E015 E017 E022 E027 E030 E031
364 1216273 E011 E013 E022 E025
333355 1216273 E001 E011 E013 E015 E017 E022 E027 E030 E031
703053 1216273 E011 E013 E022 E025
1216273 1263901 E001 E011 E027 E030
1020765 1263901 E001 E011 E027 E030
333355 1263901 E001 E011 E027 E030

(1) This graph has 10 nodes and 18 edges. The degree of a node is
defined to be the number of unique edge labeled that are linked
to this node. The maximum degree corresponds to the node with the
largest degree. In this graph, the maximum degree is 17 at node
10142.

(2) This graph has diameter of length 3. There are 3 paths of
length 3: [558814, 1026814, 10142], [1263901, 333355, 364], and
[1263901, 333355, 703053].

(3) There are 2 connected components in this graph. The largest
component has 6 nodes.

(4) The maximum clique in this graph is of size 5: {364, 333355,
703053, 1020765, 1216273}. This clique spans the edge labels
E013 and E022.
